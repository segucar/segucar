let state = {
  items: [],
  pagination: { page: 1, limit: 50, pages: 1, total: 0 },
  search: '',
  sort: { by: 'fecha_vencimiento', dir: 'DESC' }
};

document.addEventListener('DOMContentLoaded', () => {
  setupListeners();
  fetchRecuperacionItems();
});

function handleSortRecuperacion(col) {
  if (state.sort.by === col) {
    state.sort.dir = state.sort.dir === 'ASC' ? 'DESC' : 'ASC';
  } else {
    state.sort.by = col;
    state.sort.dir = 'ASC';
  }

  const cols = ['nombre', 'telefono', 'patente', 'operacion', 'vehiculo', 'fecha_vencimiento', 'estrategia'];
  cols.forEach(c => {
    const el = document.getElementById(`sort_icon_${c}`);
    if (el) {
      if (c === state.sort.by) {
        el.innerText = state.sort.dir === 'ASC' ? '▲' : '▼';
        el.className = 'sort-icon active';
      } else {
        el.innerText = '⇅';
        el.className = 'sort-icon';
      }
    }
  });

  state.pagination.page = 1;
  fetchRecuperacionItems();
}

function setupListeners() {
  const searchInput = document.getElementById('recuperacionSearchInput');
  if (searchInput) {
    let timeout;
    searchInput.addEventListener('input', (e) => {
      clearTimeout(timeout);
      timeout = setTimeout(() => {
        state.search = e.target.value.trim();
        state.pagination.page = 1;
        fetchRecuperacionItems();
      }, 300);
    });
  }
}

async function fetchRecuperacionItems() {
  const tbody = document.getElementById('recuperacionTableBody');
  if (tbody) {
    tbody.innerHTML = '<tr><td colspan="8" class="text-center" style="padding:2rem;"><div class="loading"></div></td></tr>';
  }

  try {
    const url = `/api/recuperacion?search=${encodeURIComponent(state.search)}&page=${state.pagination.page}&limit=50&sort_by=${state.sort.by}&sort_dir=${state.sort.dir}`;
    const res = await fetch(url);
    const data = await res.json();

    state.items = data.items || [];
    state.pagination = { page: data.page, limit: 50, pages: data.pages, total: data.total };

    const elTotal = document.getElementById('totalRecuperacionCount');
    if (elTotal) elTotal.innerText = `${data.total.toLocaleString('es-AR')} Pólizas`;

    renderTable();
    renderPagination();
  } catch (e) {
    console.error(e);
  }
}

function renderTable() {
  const tbody = document.getElementById('recuperacionTableBody');
  if (!tbody) return;
  tbody.innerHTML = '';

  if (state.items.length === 0) {
    tbody.innerHTML = '<tr><td colspan="8" class="text-center" style="padding:2rem; color:var(--text-secondary);">No se encontraron pólizas en la cartera de recuperación.</td></tr>';
    return;
  }

  state.items.forEach(item => {
    const tr = document.createElement('tr');
    tr.className = 'client-row';

    const fechaStr = item.fecha_vencimiento ? formatDate(item.fecha_vencimiento) : '-';
    const cleanPhone = item.telefono ? formatPhone(item.telefono) : null;
    let prioridadBadge = '<span class="badge" style="background:rgba(255,71,87,0.15); color:#ff4757; border:1px solid rgba(255,71,87,0.3);">🔥 Prioridad Alta</span>';
    if (item.fecha_vencimiento && item.fecha_vencimiento > '2026-06-01') {
      prioridadBadge = '<span class="badge" style="background:rgba(255,165,2,0.15); color:#ffa502; border:1px solid rgba(255,165,2,0.3);">🟡 Prioridad Media</span>';
    } else if (item.fecha_vencimiento && item.fecha_vencimiento > '2026-09-01') {
      prioridadBadge = '<span class="badge" style="background:rgba(255,255,255,0.1); color:#94a3b8; border:1px solid rgba(255,255,255,0.2);">⚪ Prioridad Regular</span>';
    }

    tr.innerHTML = `
      <td><strong>${escapeHtml(item.nombre || '-')}</strong></td>
      <td>${cleanPhone ? `📱 ${escapeHtml(cleanPhone)}` : '<span class="text-muted">📵 Sin teléfono</span>'}</td>
      <td><strong>${escapeHtml(item.patente || '-')}</strong></td>
      <td><span style="font-size:0.83rem; font-weight:700; color:var(--text-secondary); font-family:monospace; background:rgba(255,255,255,0.05); padding:3px 8px; border-radius:6px;">${escapeHtml(item.operacion || '-')}</span></td>
      <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${escapeHtml(item.vehiculo || '')}">${escapeHtml(item.vehiculo || '-')}</td>
      <td><span style="color:var(--danger); font-weight:600;">${fechaStr}</span></td>
      <td>${prioridadBadge}</td>
      <td>
        ${cleanPhone ? `
          <button class="btn btn-sm btn-whatsapp" onclick="sendWinBackWhatsApp('${escapeQuotes(item.nombre)}', '${escapeQuotes(cleanPhone)}', '${escapeQuotes(item.vehiculo || '')}', '${escapeQuotes(item.patente || '')}')" title="Enviar propuesta de reactivación">
            💬 Reactivar
          </button>
        ` : '-'}
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function renderPagination() {
  const container = document.getElementById('paginationControls');
  if (!container) return;
  const { page, pages } = state.pagination;

  if (pages <= 1) {
    container.innerHTML = '';
    return;
  }

  container.innerHTML = `
    <button class="btn btn-sm btn-ghost" ${page === 1 ? 'disabled' : ''} onclick="goToPage(${page - 1})">← Ant</button>
    <span style="font-size:0.9rem; font-weight:600;">Página ${page} de ${pages}</span>
    <button class="btn btn-sm btn-ghost" ${page === pages ? 'disabled' : ''} onclick="goToPage(${page + 1})">Sig →</button>
  `;
}

function goToPage(p) {
  if (p < 1 || p > state.pagination.pages) return;
  state.pagination.page = p;
  fetchRecuperacionItems();
}

function resetRecuperacionFilters() {
  state.search = '';
  const searchInput = document.getElementById('recuperacionSearchInput');
  if (searchInput) searchInput.value = '';
  state.pagination.page = 1;
  fetchRecuperacionItems();
}

function sendWinBackWhatsApp(nombre, telefono, vehiculo, patente) {
  const clean = formatPhoneForWhatsApp(telefono);
  const msg = `Hola ${nombre}, te saludamos de SEGUCar. Queremos ponernos en contacto nuevamente por tu ${vehiculo} (Dominio: ${patente}). Contamos con nuevas propuestas y excelentes coberturas para reactivar tu póliza. ¡Consultanos sin compromiso!`;
  window.open(`https://wa.me/${clean}?text=${encodeURIComponent(msg)}`, '_blank');
}

function formatDate(dateStr) {
  if (!dateStr) return '-';
  const clean = String(dateStr).split('T')[0].split(' ')[0];
  const parts = clean.split('-');
  if (parts.length === 3) {
    return `${parts[2].padStart(2, '0')}/${parts[1].padStart(2, '0')}/${parts[0]}`;
  }
  return dateStr;
}

function formatPhone(phone) {
  return phone.replace(/[\s\-\(\)]/g, '');
}

function formatPhoneForWhatsApp(phone) {
  let cleaned = phone.replace(/[\s\-\(\)]/g, '');
  if (cleaned.startsWith('+')) cleaned = cleaned.substring(1);
  if (cleaned.startsWith('0')) cleaned = cleaned.substring(1);
  if (cleaned.startsWith('15') && cleaned.length <= 10) cleaned = '549223' + cleaned.substring(2);
  else if (cleaned.startsWith('223')) cleaned = '549' + cleaned;
  else if (!cleaned.startsWith('54')) cleaned = '54' + cleaned;
  return cleaned;
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function escapeQuotes(str) {
  if (!str) return '';
  return String(str).replace(/'/g, "\\'");
}
